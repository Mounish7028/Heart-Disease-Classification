function initCharts() {
    const riskCtx = document.getElementById('riskChart').getContext('2d');
    const radarCtx = document.getElementById('radarChart').getContext('2d');
    const impactCtx = document.getElementById('impactChart').getContext('2d');

    window.riskChart = new Chart(riskCtx, {
        type: 'doughnut',
        data: {
            labels: ['No Disease', 'Low Risk', 'Med Risk', 'High Risk'],
            datasets: [{
                data: [0, 0, 0, 0],
                backgroundColor: ['#22c55e', '#38bdf8', '#f59e0b', '#ef4444'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom', labels: { color: '#94a3b8', boxWidth: 10, font: { size: 10 } } }
            },
            cutout: '70%'
        }
    });

    window.radarChart = new Chart(radarCtx, {
        type: 'radar',
        data: {
            labels: ['Age', 'BP', 'Chol', 'Heart Rate', 'ST Dep'],
            datasets: [{
                label: 'Patient Vitals (Normalized)',
                data: [0, 0, 0, 0, 0],
                backgroundColor: 'rgba(56, 189, 248, 0.2)',
                borderColor: '#38bdf8',
                borderWidth: 2,
                pointBackgroundColor: '#38bdf8'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: {
                    angleLines: { color: 'rgba(255,255,255,0.1)' },
                    grid: { color: 'rgba(255,255,255,0.1)' },
                    pointLabels: { color: '#94a3b8', font: { size: 10 } },
                    ticks: { display: false, max: 1, min: 0 }
                }
            },
            plugins: { legend: { display: false } }
        }
    });

    window.ensembleChart = new Chart(document.getElementById('ensembleChart').getContext('2d'), {
        type: 'bar',
        data: {
            labels: ['No', 'Low', 'Med', 'High'],
            datasets: [
                { label: 'MLP', data: [0, 0, 0, 0], backgroundColor: 'rgba(255, 71, 87, 0.6)' },
                { label: 'TabPFN', data: [0, 0, 0, 0], backgroundColor: 'rgba(0, 155, 158, 0.6)' }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: { beginAtZero: true, max: 1, grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#94a3b8' } },
                x: { grid: { display: false }, ticks: { color: '#94a3b8' } }
            },
            plugins: { legend: { position: 'top', labels: { color: '#94a3b8', boxWidth: 10, font: { size: 10 } } } }
        }
    });

    window.impactChart = new Chart(impactCtx, {
        type: 'bar',
        data: {
            labels: ['Age', 'Heart Rate', 'Chest Pain', 'Thal', 'Vessels', 'ST Dep'],
            datasets: [{
                label: 'Model Impact',
                data: [0, 0, 0, 0, 0, 0],
                backgroundColor: '#009B9E',
                borderRadius: 5
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: { beginAtZero: true, grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#94a3b8' } },
                x: { grid: { display: false }, ticks: { color: '#94a3b8' } }
            },
            plugins: { legend: { display: false } }
        }
    });
}

function updateCharts(data, rawInput) {
    if (window.riskChart) {
        window.riskChart.data.datasets[0].data = data.probabilities;
        window.riskChart.update();
    }

    if (window.radarChart) {
        const norm = [
            (rawInput.age - 20) / 80,
            (rawInput.trestbps - 90) / 110,
            (rawInput.chol - 100) / 400,
            (rawInput.thalach - 60) / 160,
            (rawInput.oldpeak) / 6
        ];
        window.radarChart.data.datasets[0].data = norm.map(v => Math.min(Math.max(v, 0), 1));
        window.radarChart.update();
    }

    if (window.ensembleChart && data.ensemble_info) {
        window.ensembleChart.data.datasets[0].data = data.ensemble_info.mlp_probs;
        window.ensembleChart.data.datasets[1].data = data.ensemble_info.tabpfn_probs;
        window.ensembleChart.update();
    }

    if (window.impactChart) {
        const imp = data.feature_importance;
        window.impactChart.data.datasets[0].data = [
            imp.age, imp.thalach, imp.cp, imp.thal, imp.ca, imp.oldpeak
        ];
        window.impactChart.update();
    }
}
