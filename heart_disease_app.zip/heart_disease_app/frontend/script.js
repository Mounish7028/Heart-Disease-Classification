document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('prediction-form');
    const loader = document.getElementById('loader-container');
    const dashboard = document.getElementById('results-dashboard');
    const statusText = document.getElementById('status-text');
    const navLinks = document.querySelectorAll('.nav-links li');
    const sections = document.querySelectorAll('.section');

    // Date Update
    document.getElementById('current-date').textContent = new Date().toLocaleDateString('en-US', {
        month: 'long', day: 'numeric', year: 'numeric'
    });

    // Real-time Input Feedback
    const inputs = form.querySelectorAll('input');
    inputs.forEach(input => {
        input.addEventListener('input', () => {
            const val = parseFloat(input.value);
            const id = input.id;

            if (id === 'trestbps') {
                input.style.borderColor = val > 140 ? '#ef4444' : (val > 120 ? '#f59e0b' : '#22c55e');
            } else if (id === 'chol') {
                input.style.borderColor = val > 240 ? '#ef4444' : (val > 200 ? '#f59e0b' : '#22c55e');
            } else if (id === 'thalach') {
                input.style.borderColor = (val < 60 || val > 100) ? '#f59e0b' : '#22c55e';
            } else if (id === 'oldpeak') {
                input.style.borderColor = val > 2.0 ? '#ef4444' : (val > 1.0 ? '#f59e0b' : '#22c55e');
            }
        });
    });

    // Sidebar Navigation
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            const sectionId = link.dataset.section;
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');

            sections.forEach(s => {
                s.classList.remove('active');
                if (s.id === `${sectionId}-section`) s.classList.add('active');
            });
        });
    });

    // Initialize Charts
    initCharts();

    // Initialize Reports
    loadReports();

    // Form Submission
    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());

        // Reset and Show Loader
        dashboard.classList.add('hidden');
        loader.classList.remove('hidden');

        const sequence = [
            "Initializing neural network...",
            "Analyzing 13 biomarkers...",
            "Checking clinical heuristics...",
            "Processing ensemble layers...",
            "Generating medical report..."
        ];

        let seqIdx = 0;
        const seqInterval = setInterval(() => {
            if (seqIdx < sequence.length) {
                statusText.textContent = sequence[seqIdx++];
            }
        }, 600);

        try {
            const response = await fetch('http://localhost:5000/api/predict', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            clearInterval(seqInterval);

            if (response.ok) {
                // Short delay to let user see final status
                setTimeout(() => {
                    loader.classList.add('hidden');
                    renderResults(result, data);
                }, 800);
            } else {
                let msg = result.error || 'Unknown error';
                if (result.details) {
                    msg += ":\n" + Object.entries(result.details)
                        .map(([field, error]) => `- ${field}: ${error}`)
                        .join('\n');
                }
                alert(`Analysis Error: ${msg}`);
                loader.classList.add('hidden');
            }
        } catch (error) {
            clearInterval(seqInterval);
            alert("Connection error: Ensure Flask backend is running on port 5000");
            loader.classList.add('hidden');
        }
    });

    function renderResults(data, rawInput) {
        dashboard.classList.remove('hidden');

        const riskDisplay = document.getElementById('risk-level-display');
        const confValue = document.getElementById('confidence-value');
        const recList = document.getElementById('rec-list');
        const flagsDiv = document.getElementById('clinical-flags');

        riskDisplay.textContent = data.risk_level || "Unknown";
        riskDisplay.className = 'risk-indicator';

        const riskNorm = (data.risk_level || "").toLowerCase();
        if (riskNorm.includes('no disease')) riskDisplay.classList.add('risk-low');
        else if (riskNorm.includes('low')) riskDisplay.classList.add('risk-low');
        else if (riskNorm.includes('medium')) riskDisplay.classList.add('risk-med');
        else if (riskNorm.includes('high')) riskDisplay.classList.add('risk-high');

        confValue.textContent = `${(data.confidence || 0).toFixed(1)}%`;

        // Clinical Flags (Safety check)
        const flags = data.clinical_flags || [];
        flagsDiv.innerHTML = flags.length > 0
            ? flags.map(f => `• ${f}`).join('<br>')
            : "No immediate clinical abnormalities detected.";

        // Update Charts
        try {
            updateCharts(data, rawInput);
        } catch (e) {
            console.error("Chart update error:", e);
        }

        // Sensible Recommendations
        const recs = [];

        // Rule-based medical advice
        if (parseFloat(rawInput.trestbps) >= 140) recs.push("High blood pressure detected. Reduce sodium and monitor daily.");
        if (parseFloat(rawInput.chol) >= 240) recs.push("High cholesterol level. Low-fat diet and lipid profile review recommended.");
        if (parseFloat(rawInput.oldpeak) >= 2.0) recs.push("Critical ST depression noted. Cardiologist consultation highly advised.");
        if (parseInt(rawInput.ca) >= 1) recs.push("Major vessel involvement detected. Follow up for imaging.");

        // AI-based advice
        let prediction = 0;
        if (riskNorm.includes('no disease')) prediction = 0;
        else if (riskNorm.includes('low')) prediction = 1;
        else if (riskNorm.includes('medium')) prediction = 2;
        else if (riskNorm.includes('high')) prediction = 3;

        if (prediction >= 2) recs.push("AI Model indicates moderate to high risk. Schedule a stress test.");
        if (prediction === 0 && recs.length === 0) recs.push("Keep maintaining your healthy lifestyle and routine checkups.");

        if (recs.length === 0) recs.push("Diagnostic values are within acceptable medical ranges.");

        recList.innerHTML = recs.map(r => `<li>${r}</li>`).join('');

        // Final Scroll correction - ensure top of results is visible
        dashboard.scrollIntoView({ behavior: 'smooth', block: 'start' });

        // Save to History (wait for charts to render)
        setTimeout(() => {
            saveReportToHistory(data, rawInput, recs, flags);
        }, 1500);
    }

    function saveReportToHistory(data, rawInput, recs, flags) {
        try {
            const getChartData = (id) => {
                const canvas = document.getElementById(id);
                if (canvas) return canvas.toDataURL('image/jpeg', 0.8);
                return null;
            };

            const report = {
                id: Date.now().toString(),
                timestamp: new Date().toISOString(),
                inputs: rawInput,
                outputs: {
                    risk_level: data.risk_level,
                    confidence: data.confidence
                },
                recommendations: recs,
                clinical_flags: flags,
                charts: {
                    risk_chart: getChartData('riskChart'),
                    radar_chart: getChartData('radarChart'),
                    ensemble_chart: getChartData('ensembleChart'),
                    impact_chart: getChartData('impactChart')
                }
            };

            let history = JSON.parse(localStorage.getItem('cardio_reports') || '[]');
            history.unshift(report);
            
            // Limit to 20 to avoid QuotaExceededError
            if (history.length > 20) history = history.slice(0, 20);
            
            localStorage.setItem('cardio_reports', JSON.stringify(history));
            loadReports();
        } catch (e) {
            console.error("Failed to save report:", e);
        }
    }

    function loadReports() {
        const container = document.getElementById('reports-container');
        if (!container) return;
        
        let history = JSON.parse(localStorage.getItem('cardio_reports') || '[]');
        
        if (history.length === 0) {
            container.innerHTML = '<div class="empty-state"><p>No reports generated yet. Run a diagnosis to see history here.</p></div>';
            return;
        }

        container.innerHTML = history.map(report => {
            const date = new Date(report.timestamp).toLocaleString();
            let badgeClass = 'risk-med';
            const riskNorm = (report.outputs.risk_level || "").toLowerCase();
            if (riskNorm.includes('no disease') || riskNorm.includes('low')) badgeClass = 'risk-low';
            else if (riskNorm.includes('high')) badgeClass = 'risk-high';

            const gender = report.inputs.sex === "1" ? "Male" : "Female";
            const sugar = report.inputs.fbs === "1" ? ">120 mg/dL" : "≤120 mg/dL";

            return `
                <div class="report-card">
                    <div class="report-header">
                        <span class="report-timestamp">${date}</span>
                        <span class="report-badge ${badgeClass}">${report.outputs.risk_level}</span>
                    </div>
                    <div class="report-details">
                        <div><span>Patient Age</span><p>${report.inputs.age} yrs</p></div>
                        <div><span>Gender</span><p>${gender}</p></div>
                        <div><span>Blood Sugar</span><p>${sugar}</p></div>
                        <div><span>Resting BP</span><p>${report.inputs.trestbps} mmHg</p></div>
                        <div><span>Model Confidence</span><p>${(report.outputs.confidence || 0).toFixed(1)}%</p></div>
                    </div>
                    <div class="report-actions">
                        <button class="report-btn btn-download" onclick="downloadReport('${report.id}')">
                            📄 Download
                        </button>
                        <button class="report-btn btn-delete" onclick="deleteReport('${report.id}')">
                            🗑️ Delete
                        </button>
                    </div>
                </div>
            `;
        }).join('');
    }

    window.downloadReport = async (id) => {
        let history = JSON.parse(localStorage.getItem('cardio_reports') || '[]');
        const report = history.find(r => r.id === id);
        if (!report) return;

        try {
            const response = await fetch('http://localhost:5000/api/generate_report', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(report)
            });

            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `CardioAI_Report_${new Date(report.timestamp).getTime()}.docx`;
                document.body.appendChild(a);
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
            } else {
                alert("Failed to generate document.");
            }
        } catch (error) {
            console.error("Download error:", error);
            alert("Connection error while generating report.");
        }
    };

    window.deleteReport = (id) => {
        if (!confirm("Are you sure you want to delete this report?")) return;
        let history = JSON.parse(localStorage.getItem('cardio_reports') || '[]');
        history = history.filter(r => r.id !== id);
        localStorage.setItem('cardio_reports', JSON.stringify(history));
        loadReports();
    };
});
