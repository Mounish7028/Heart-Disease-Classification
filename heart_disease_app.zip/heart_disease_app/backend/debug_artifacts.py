import joblib
import numpy as np
import os

models_dir = "heart_disease_app/backend/models"
le = joblib.load(os.path.join(models_dir, "label_encoder.pkl"))
print(f"LabelEncoder classes: {le.classes_}")

pso_w1 = np.load(os.path.join(models_dir, "pso_best_weight.npy"))
print(f"PSO w1 (TabPFN weight): {pso_w1}")

scaler = joblib.load(os.path.join(models_dir, "scaler.pkl"))
print(f"Scaler mean: {scaler.mean_}")
print(f"Scaler scale: {scaler.scale_}")
