def validate_input(data):
    rules = {
        "age": {"min": 20, "max": 100},
        "sex": {"valid": [0, 1]},
        "cp": {"valid": [0, 1, 2, 3]},
        "trestbps": {"min": 90, "max": 200},
        "chol": {"min": 100, "max": 600},
        "fbs": {"valid": [0, 1]},
        "restecg": {"valid": [0, 1, 2]},
        "thalach": {"min": 60, "max": 220},
        "exang": {"valid": [0, 1]},
        "oldpeak": {"min": 0, "max": 10},
        "slope": {"valid": [0, 1, 2]},
        "ca": {"valid": [0, 1, 2, 3, 4]},
        "thal": {"valid": [0, 1, 2, 3]}
    }
    
    errors = {}
    for field, rule in rules.items():
        if field not in data:
            errors[field] = "Field is required"
            continue
        
        val = data[field]
        if "min" in rule and "max" in rule:
            if not (rule["min"] <= float(val) <= rule["max"]):
                errors[field] = f"Must be between {rule['min']} and {rule['max']}"
        elif "valid" in rule:
            if int(val) not in rule["valid"]:
                errors[field] = f"Must be one of {rule['valid']}"
                
    return errors
