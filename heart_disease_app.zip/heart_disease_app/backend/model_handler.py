import os
import joblib
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.model_selection import train_test_split
from tabpfn import TabPFNClassifier
from tabpfn.model_loading import load_fitted_tabpfn_model, save_fitted_tabpfn_model
from tabpfn.finetune_utils import clone_model_for_evaluation

# Re-define MLPNet as it's needed for torch.load
class MLPNet(nn.Module):
    def __init__(self, input_dim, hidden_dims=[128,64], output_dim=2, dropout=0.2):
        super().__init__()
        layers = []
        prev = input_dim
        for h in hidden_dims:
            layers.append(nn.Linear(prev, h))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(dropout))
            prev = h
        layers.append(nn.Linear(prev, output_dim))
        self.net = nn.Sequential(*layers)
    def forward(self, x):
        return self.net(x)

class ModelHandler:
    def __init__(self, models_dir="models"):
        self.models_dir = models_dir
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        
        # Load artifacts
        self.scaler = joblib.load(os.path.join(models_dir, "scaler.pkl"))
        self.le = joblib.load(os.path.join(models_dir, "label_encoder.pkl"))
        self.pso_w1 = np.load(os.path.join(models_dir, "pso_best_weight.npy"))
        
        # Load MLP
        input_dim = 13 # Heart dataset features
        output_dim = len(self.le.classes_)
        self.mlp_model = MLPNet(input_dim=input_dim, output_dim=output_dim)
        self.mlp_model.load_state_dict(torch.load(os.path.join(models_dir, "mlp_model.pt"), map_location=self.device))
        self.mlp_model.to(self.device)
        self.mlp_model.eval()
        
        # Load TabPFN
        self.tabpfn_classifier = load_fitted_tabpfn_model(os.path.join(models_dir, "tabpfn_model.tabpfn_fit"))
        
        # Reconstruct X_train, y_train context for TabPFN
        self._prepare_context()

    def _prepare_context(self):
        # Replicate notebook logic to get exact X_train, y_train
        data_path = os.path.join(self.models_dir, "heart.csv")
        df = pd.read_csv(data_path)
        
        # Medical risk rules
        df['risk_level'] = 0
        disease_mask = df['target'] == 1
        low_risk_mask = (df['oldpeak'] < 1.0) & (df['trestbps'] < 140) & (df['chol'] < 250)
        medium_risk_mask = (((df['oldpeak'] >= 1.0) & (df['oldpeak'] < 2.5)) | ((df['trestbps'] >= 140) & (df['trestbps'] < 160)) | ((df['chol'] >= 250) & (df['chol'] < 300)))
        high_risk_mask = ((df['oldpeak'] >= 2.5) | (df['trestbps'] >= 160) | (df['chol'] >= 300))
        df.loc[disease_mask & low_risk_mask, 'risk_level'] = 1
        df.loc[disease_mask & medium_risk_mask, 'risk_level'] = 2
        df.loc[disease_mask & high_risk_mask, 'risk_level'] = 3
        
        X_all = df.drop(columns=['target', 'risk_level']).values
        y_all = self.le.transform(df['risk_level'].values)
        
        # Split logic
        test_size = 0.2
        val_size = 0.2
        seed = 42
        
        X_temp, X_test, y_temp, y_test = train_test_split(X_all, y_all, test_size=test_size, stratify=y_all, random_state=seed)
        val_frac_of_temp = val_size / (1.0 - test_size)
        X_train, X_val, y_train, y_val = train_test_split(X_temp, y_temp, test_size=val_frac_of_temp, stratify=y_temp, random_state=seed)
        
        self.X_train_scaled = self.scaler.transform(X_train)
        self.y_train = y_train
        
        # Inference config for TabPFN
        self.eval_config = {
            "device": self.device,
            "inference_config": {"SUBSAMPLE_SAMPLES": 10000},
            "n_estimators": 2,
            "inference_precision": torch.float32
        }

    def predict(self, input_data):
        # input_data is a dict with 13 features
        features = ["age", "sex", "cp", "trestbps", "chol", "fbs", "restecg", "thalach", "exang", "oldpeak", "slope", "ca", "thal"]
        X_new = np.array([[input_data[f] for f in features]])
        X_new_scaled = self.scaler.transform(X_new)
        
        # MLP prediction
        X_new_t = torch.tensor(X_new_scaled, dtype=torch.float32).to(self.device)
        with torch.no_grad():
            logits_mlp = self.mlp_model(X_new_t)
            probs_mlp = torch.softmax(logits_mlp, dim=1).cpu().numpy()
            
        # TabPFN prediction
        # Use clone_model_for_evaluation as in the notebook
        eval_classifier = clone_model_for_evaluation(self.tabpfn_classifier, self.eval_config, TabPFNClassifier)
        eval_classifier.fit(self.X_train_scaled, self.y_train)
        probs_tabpfn = eval_classifier.predict_proba(X_new_scaled)
        
        # Ensemble prediction
        probs_ensemble = self.pso_w1 * probs_tabpfn + (1.0 - self.pso_w1) * probs_mlp
        prediction = int(np.argmax(probs_ensemble, axis=1)[0])
        confidence = float(np.max(probs_ensemble) * 100)
        
        risk_levels = ["No Disease", "Low Risk", "Medium Risk", "High Risk"]
        risk_level = risk_levels[prediction]
        
        # Clinical Heuristics for "Sensibility"
        # If vitals are extremely high, we should at least flag it even if model says 0
        clinical_flags = []
        if float(input_data['trestbps']) >= 180: clinical_flags.append("Hypertensive Crisis Level BP")
        if float(input_data['oldpeak']) >= 2.0: clinical_flags.append("Significant ST Depression")
        if int(input_data['ca']) >= 2: clinical_flags.append("Multiple Major Vessels Involved")
        if int(input_data['thal']) == 2: clinical_flags.append("Reversible Thalassemia Defect")

        # Override risk level if extremely critical biomarkers detected
        if (float(input_data['trestbps']) >= 190 or float(input_data['oldpeak']) >= 2.5) and prediction == 0:
            risk_level = "High Risk (Clinical Override)"
            confidence = 90.0 # Force high confidence for clip/safety

        return {
            "prediction": prediction,
            "confidence": confidence,
            "risk_level": risk_level,
            "clinical_flags": clinical_flags,
            "probabilities": probs_ensemble[0].tolist(),
            "ensemble_info": {
                "mlp_probs": probs_mlp[0].tolist(),
                "tabpfn_probs": probs_tabpfn[0].tolist(),
                "pso_weight": float(self.pso_w1)
            },
            "feature_importance": self._calculate_basic_importance(input_data)
        }

    def _calculate_basic_importance(self, input_data):
        # Improved heuristic based on common medical weighting
        importance = {
            "age": 0.12,
            "thalach": 0.18,
            "cp": 0.22,
            "thal": 0.15,
            "ca": 0.10,
            "oldpeak": 0.15,
            "trestbps": 0.04,
            "chol": 0.02,
            "slope": 0.01,
            "exang": 0.01,
            "restecg": 0.00,
            "fbs": 0.00,
            "sex": 0.00
        }
        # Boost importance if values are abnormal
        if float(input_data['trestbps']) > 160: importance['trestbps'] += 0.1
        if float(input_data['oldpeak']) > 2.0: importance['oldpeak'] += 0.1
        if int(input_data['cp']) == 3: importance['cp'] += 0.1
        
        # Normalize
        total = sum(importance.values())
        return {k: v/total for k, v in importance.items()}
