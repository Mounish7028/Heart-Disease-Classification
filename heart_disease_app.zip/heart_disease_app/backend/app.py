from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import os
import io
import base64
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from model_handler import ModelHandler
from utils.validators import validate_input

app = Flask(__name__, static_folder='../frontend', static_url_path='')
CORS(app)

# Initialize Model Handler
model_handler = ModelHandler(models_dir="models")

@app.route('/')
def index():
    return app.send_static_file('index.html')

@app.route('/api/predict', methods=['POST'])
def predict():
    data = request.get_json()
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    # Validate input
    print(f"DEBUG: Incoming data: {data}")
    errors = validate_input(data)
    if errors:
        print(f"DEBUG: Validation errors: {errors}")
        return jsonify({"error": "Validation failed", "details": errors}), 400
    
    try:
        result = model_handler.predict(data)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/normal-ranges', methods=['GET'])
def get_normal_ranges():
    ranges = {
        "age": {"min": 20, "max": 100, "average": 54.4},
        "trestbps": {"min": 90, "max": 200, "average": 131.6, "normal": "90-140 mmHg"},
        "chol": {"min": 100, "max": 600, "average": 246.7, "normal": "<200 mg/dL"},
        "thalach": {"min": 60, "max": 220, "average": 149.1, "normal": "60-100 bpm (resting)"},
        "oldpeak": {"min": 0, "max": 10, "average": 1.04, "normal": "0-1"},
        "sex": {"0": "Female", "1": "Male"},
        "cp": {"0": "Typical Angina", "1": "Atypical Angina", "2": "Non-anginal Pain", "3": "Asymptomatic"},
        "fbs": {"0": "≤120 mg/dL", "1": ">120 mg/dL"},
        "restecg": {"0": "Normal", "1": "ST-T Abnormality", "2": "LV Hypertrophy"},
        "exang": {"0": "No", "1": "Yes"},
        "slope": {"0": "Upsloping", "1": "Flat", "2": "Downsloping"},
        "ca": {"0": "0", "1": "1", "2": "2", "3": "3", "4": "4"},
        "thal": {"0": "Normal", "1": "Fixed Defect", "2": "Reversible Defect", "3": "Unknown"}
    }
    return jsonify(ranges)

@app.route('/api/model-info', methods=['GET'])
def get_model_info():
    # These metrics are extracted from final_summary.csv in the models folder
    info = {
        "ensemble_accuracy": 97.07,
        "tabpfn_accuracy": 96.10,
        "mlp_accuracy": 73.66,
        "ensemble_auc": 99.80,
        "precision": 97.42,
        "recall": 97.65,
        "f1_score": 97.48,
        "model_type": "Ensemble (MLP + TabPFN with PSO Optimization)"
    }
    return jsonify(info)

@app.route('/api/generate_report', methods=['POST'])
def generate_report():
    data = request.get_json()
    if not data:
        return jsonify({"error": "No data provided"}), 400

    try:
        doc = Document()
        
        # Styles for the document
        style = doc.styles['Normal']
        font = style.font
        font.name = 'Arial'
        font.size = Pt(11)
        
        # Title
        title = doc.add_heading('Heart Disease Risk Assessment Report', 0)
        title.alignment = 1 # Center
        
        # Section 1: Patient Information (Inputs)
        doc.add_heading('1. Patient Information', level=1)
        inputs = data.get('inputs', {})
        p = doc.add_paragraph()
        p.add_run(f"Age: {inputs.get('age', 'N/A')} | Sex: {'Male' if str(inputs.get('sex')) == '1' else 'Female'}\n")
        p.add_run(f"Resting BP: {inputs.get('trestbps', 'N/A')} mmHg | Cholesterol: {inputs.get('chol', 'N/A')} mg/dL\n")
        p.add_run(f"Max Heart Rate: {inputs.get('thalach', 'N/A')} bpm | Fasting Blood Sugar: {'> 120 mg/dL' if str(inputs.get('fbs')) == '1' else '≤ 120 mg/dL'}\n")
        p.add_run(f"ST Depression (oldpeak): {inputs.get('oldpeak', 'N/A')} | Major Vessels (ca): {inputs.get('ca', 'N/A')}\n")
        
        # Section 2: Model Analysis Results
        doc.add_heading('2. Model Analysis Results', level=1)
        outputs = data.get('outputs', {})
        p2 = doc.add_paragraph()
        run = p2.add_run(f"Assessed Risk Level: {outputs.get('risk_level', 'Unknown')}\n")
        run.bold = True
        if 'High' in str(outputs.get('risk_level', '')):
            run.font.color.rgb = RGBColor(0xFF, 0x00, 0x00) # Red
        p2.add_run(f"Model Confidence: {outputs.get('confidence', 'N/A')}%\n")

        # Section 3: Clinical Flags & Recommendations
        doc.add_heading('3. Clinical Flags & Recommendations', level=1)
        flags = data.get('clinical_flags', [])
        doc.add_heading('Clinical Flags:', level=2)
        if flags:
            for flag in flags:
                doc.add_paragraph(flag, style='List Bullet')
        else:
            doc.add_paragraph("No immediate clinical abnormalities detected.")

        recs = data.get('recommendations', [])
        doc.add_heading('Recommendations:', level=2)
        if recs:
            for rec in recs:
                doc.add_paragraph(rec, style='List Bullet')
        else:
            doc.add_paragraph("No specific recommendations provided.")

        # Section 4: Visualizations
        doc.add_heading('4. Visualizations', level=1)
        charts = data.get('charts', {})
        for chart_name, base64_data in charts.items():
            if base64_data:
                try:
                    # Remove the data:image/png;base64, part if present
                    if ',' in base64_data:
                        base64_data = base64_data.split(',')[1]
                    image_data = base64.b64decode(base64_data)
                    image_stream = io.BytesIO(image_data)
                    doc.add_paragraph(f"{chart_name.replace('_', ' ').title()}:")
                    doc.add_picture(image_stream, width=Inches(5.5))
                except Exception as e:
                    print(f"Error embedding chart {chart_name}: {e}")

        # Footer
        doc.add_paragraph("\nDisclaimer: This report is generated by an AI model evaluating clinical features and is intended for informational and demonstrative purposes only. It should not replace professional medical advice, diagnosis, or treatment.", style='Intense Quote')

        # Save to memory stream
        mem_stream = io.BytesIO()
        doc.save(mem_stream)
        mem_stream.seek(0)
        
        return send_file(
            mem_stream,
            as_attachment=True,
            download_name='Heart_Disease_Assessment_Report.docx',
            mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        )
    except Exception as e:
        print(f"Error generating report: {e}")
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
