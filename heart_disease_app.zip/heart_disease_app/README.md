# Heart Disease Classifier v1.0

A modern full-stack web application that predicts heart disease risk levels using an ensemble of MLP (Multi-Layer Perceptron) and TabPFN models, optimized via Particle Swarm Optimization (PSO).

## Features
- **Advanced AI Analysis**: Leverages a hybrid ensemble model with 97.07% accuracy.
- **Modern Medical Dashboard**: Glassmorphism UI with real-time feedback and Chart.js visualizations.
- **Interactive Vitals Input**: 13 biomarker fields with validation and normal range tooltips.
- **Heartbeat Animation**: Premium 60 FPS SVG/CSS animation with live ECG waveform.
- **Comprehensive Results**: Risk distribution charts, biomarker impact analysis, and medical recommendations.

## Tech Stack
- **Backend**: Flask REST API, PyTorch, TabPFN, Scikit-learn, NumPy, Pandas.
- **Frontend**: Vanilla HTML5, CSS3, JavaScript (ES6+), Chart.js.

## Setup Instructions

### 1. Backend Setup
1. Navigate to the backend directory:
   ```bash
   cd backend
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the Flask server:
   ```bash
   python app.py
   ```
   The API will start at `http://localhost:5000`.

### 2. Frontend Setup
1. Navigate to the frontend directory:
   ```bash
   cd frontend
   ```
2. Open `index.html` in any modern web browser.

## Model Details
- **Base Models**: MLPNet (PyTorch) + TabPFNClassifier.
- **Ensemble Strategy**: Weighted average of probabilities.
- **Optimization**: PSO (Particle Swarm Optimization) was used to find the optimal ensemble weights (w1=0.5248, w2=0.4752).
- **Metric Performance**:
    - Accuracy: 97.07%
    - ROC AUC: 0.9980
    - F1 Score: 97.48%

## Directory Structure
```
heart_disease_app/
├── backend/
│   ├── app.py             # Flask API Shell
│   ├── model_handler.py   # Prediction Engine
│   ├── requirements.txt   # Dependencies
│   ├── models/            # Model Weights & Scaler
│   └── utils/             # Validation logic
└── frontend/
    ├── index.html         # Main UI
    ├── style.css          # Premium Styles
    ├── script.js          # App Logic
    └── assets/            # Animations & Charts
```
